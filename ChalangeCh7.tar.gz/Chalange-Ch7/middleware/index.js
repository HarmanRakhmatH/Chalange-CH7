const { Token } = require("../utils");

class Middleware {
    static authentication(req, res, next) {
        try {
            const token = req.headers.token || req.body.token; // kalau req.headers nilainya falsy dia akan mengambil dari req.body
            if (token) {

                const payload = Token.decodeToken(token);
                console.log(payload, "<< PAYLOAD")
                if (payload) {
                    req.headers.userLogin = payload;
                    next();
                } else {
                    res.status(401).json({
                        msg: "Unauthorize",
                    });
                }
            } else {
                res.status(401).json({
                    msg: "Unauthorize",
                });
            }
        } catch (error) {
            res.status(500).json({
                msg: "Something Wrong",
            });
        }
    }

    static authorization(req, res, next) {
        // authorization bisa dipakai untuk check superAdmin
        try {
            // cara pertama const token = req.headers.token || req.body.token;
            // const token = req.headers.token || req.body.token; // kao ada nilai req. headers .token , kalo gk ada dapatnya req.body.token
            // cara kedua const token = req.headers.token || req.query.token; dapat token dari query
            const token = req.headers.token || req.query.token;
            const payload = Token.decodeToken(token);
            const _role = payload && payload.role ? payload.role : null; // ktia mabahkan logic  suatu variabel diawali dengan kata is itu baisanya di sebut back in
            // const isAdmin =  payload.role ini ada dua kemungkinan dia bisa datanya undefinde atau role ada ini kondisi true false
            // cara bacanya payload && payload.role ? payload.role : null kalau payload ada dan payload.token ada maka di ambil payload.token  kalau payload gak ada maka dia mengambil null
            // if(payload && role === "SA") pakai cara ini juga bisa tanpa menggunakan cara pertama dengan ternary option
            // cara ketiga ini bisa di singkat seperti di line 33
            //  var _role
            // if(payload && payload.role) {
            //   _role = payload.role
            // } else {
            //   _role = null
            // }
            // cara kedua
            console.log(token, "<<< TOKEN");
            if (_role === "SA") {
                // req.headers.userLogin = payload;
                next();
            } else {
                res.status(401).json({ msg: "Unauthorization" })
            }
            // cara pertama
            // if (payload) {
            //   req.headers.userLogin = payload;
            //   next();
            // } else {
            //   res.status(401).json({ msg: "Unauth" });
            // }
        } catch (error) {
            console.log(error)
            res.status(500).json({
                msg: "Something Wrong",
            });
        }
    }
}

module.exports = Middleware;
