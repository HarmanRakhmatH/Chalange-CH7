const { User } = require("../models");
const { Token } = require("../utils");

class UserController {
    static async getAllUsers(req, res, next) {
        try {
            const userLogin = req.headers.userLogin;
            console.log(userLogin);
            const users = await User.findAll();
            res.status(200).json(users);
        } catch (error) { }
    }

    static async register(req, res, next) {
        try {
            console.log(req.body, "<<< ");
            const { name, password, role } = req.body;
            if (password.length < 8) {
                // password.length kurang dari 8
                res.status(400).json({
                    msg: "Periksa kembali data data login anda",
                });
            }
            const payload = {
                name,
                password,
                role,
            };
            const newUser = await User.create(payload);
            // const userID = newUser.id // id nya ini bisa dipakai untuk userId biodata
            //   const bioPayload = {
            //     UserId : newUser.dataValues.id
            //   }
            //   const bioUser = await UserBiodata.create(payload)
            // jadi di create dulu baru di get
            // const data = await User.findOne({  // kalo mau join ke biodata_user
            //     include: [
            //       {
            //         models : "biodata_user"
            //       }
            //     ]
            // })
            console.log(newUser, "<<< NEW USER");
            // res.status(200).json(newUser);
            res.status(200).json({
                msg: "Register berhasil, Silahkan Login",
            });
        } catch (error) {
            res.status(200).json({
                msg: "Username has already",
            });
            console.log(error);
        }
    }

    // static async registerBiodata(req, res, next) {
    //     try {
    //         const userID = newUser.id // id nya ini bisa dipakai untuk userId biodata
    //         const bioPayload = {
    //             UserId: newUser.dataValues.id
    //         }
    //         const bioUser = await UserBiodata.create(payload)
    //         // jadi di create dulu baru di get
    //         const data = await User.findOne({  // kalo mau join ke biodata_user
    //             include: [
    //                 {
    //                     models: "biodata_user"
    //                 }
    //             ]
    //         })

    //     } catch (error) {

    //     }
    // }
    static async login(req, res, next) {
        try {
            const { name, password } = req.body;
            console.log(req.headers, "<<<< 1");
            const loginUser = await User.findOne({
                where: {
                    name: name,
                },
            });

            const _id = loginUser.dataValues.id;
            const _password = loginUser.dataValues.password; // ini adalah password di dapat dari database
            if (password !== _password) {
                // jika password di dapat dari req body tidak sama dengan password di dapat dari database benar
                res.status(401).json({
                    msg: "Password or name invalid",
                });
            } else {
                const _role = loginUser.dataValues.role;
                const token = Token.generateToken({ name, role: _role, id: _id });
                // window.localStorage.setItem("tokeen", token);
                if (token) {
                    req.headers.token = token;
                    // cara pertmaa sessionStorage atau localSTorage
                    // sessionStorage.setItem("token", token);
                    // ketiga res.render("home", {token})
                    // res.render("home", { token });
                    // cara kedua   res.render("home", { token: req.query.token });
                    // res.render("home", { token: req.query.token });
                    //cara pertama res.redirect si token gak aman karna token terlihat  res.redirect("/" + "?token=" + token);
                    // res.redirect("/" + "?token=" + token);
                    // console.log(req.headers, "<<<< 2");

                    res.status(200).json({ token });
                }
            }
        } catch (error) {
            console.log(error);
        }
    }


    static async loginPage(req, res, next) {
        try {
            res.render("login");
        } catch (error) { }
    }

    static async homePage(req, res, next) {
        try {
            // kirim token lewat headers gk berhasil hanya muncul udefined saat di ocnsole log
            // console.log(req.headers.token, "<<<");
            // cara 2
            // console.log(req.query.token, "<<<");
            console.log(req.loginUser);
            // cara pertama res.render("home", { user: req.loginUser });
            // cara kedua
            res.render("home", { user: req.headers.userLogin });
        } catch (error) {
            console.log(error);
        }
    }


}

module.exports = UserController;
