const UserController = require("./ControlPanelUser")
const RoomController = require("./controlroom")

module.exports = {
    UserController,
    RoomController
}