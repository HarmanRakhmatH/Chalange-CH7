const { Room, UserRoom, GameHistory } = require("../models");

class RoomController {
    static async createRoom(req, res, next) {
        try {
            const { name } = req.body;
            //cara pertama variabel newRoom
            //   const newRoom = await Room.create({ name });
            //cara kedua tanpa variable langsng await
            await Room.create({ name });
            res.status(200).json({
                msg: "success create room",
            });
        } catch (error) {
            console.log(error);
        }
    }

    static async registerRoom(req, res, next) {
        try {
            const { id } = req.headers.userLogin // data user
            const room_id = req.params.id;
            const input = req.body.input

            await UserRoom.create({ UserId: id, RoomId: room_id });
            const room = await GameHistory.findOne({
                where: {
                    RoomId: room_id
                }
            })
            const roomHistory = room
            // const player1 = room.dataValues.player1Choosen

            if (roomHistory) {
                const player1 = room.dataValues.player1Choosen
                console.log(player1)
            } else {
                await GameHistory.create({
                    RoomId: room_id,
                    player1Choosen: input
                })
            }


            res.status(200).json({ msg: `Welcome to room ${room_id}` });
        } catch (error) {
            console.log(error);
        }
    }
}

module.exports = RoomController;
