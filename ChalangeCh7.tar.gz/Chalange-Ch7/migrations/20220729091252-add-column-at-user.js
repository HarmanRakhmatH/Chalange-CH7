"use strict";

module.exports = {
  async up(queryInterface, Sequelize) {
    queryInterface.addColumn("Users", "role", { type: Sequelize.STRING });
  },

  async down(queryInterface, Sequelize) {
    // jadi istilah dari di down ada inversi dari kebalikan di up , jadi kalo di up addcolumn  maka di down deletecolumn
    queryInterface.removeColumn("Users", "role", {});
  },
};
// keynote jika kita menjalakan perintah db:migrate  maka dia akan menjalankan up yang status masih down
// keynote kalo kita menjalankan perintah db:migrate:undo dia aka menjalankan down yang status masih up
