const route = require("express").Router();
const { UserController, RoomController } = require("../controller");
const Middleware = require("../middleware");

// User Controller
route.post("/register", UserController.register);
route.post("/login", UserController.login);
route.get("/users", Middleware.authorization, UserController.getAllUsers);

// userController loginPage
route.get("/login-page", UserController.loginPage);
route.get("/", Middleware.authorization, UserController.homePage);

// Room COntroller
route.post("/room", RoomController.createRoom);
route.post("/fight/:id", Middleware.authentication, RoomController.registerRoom);

module.exports = route;
